import UIKit
//
var name: [String: String] = ["AAPL": "Apple Stock Market"]
print(name["AAPL"])

//
var phoneNumber: String? = "081290091111"
phoneNumber = nil
if let number = phoneNumber{
    print("My phone number: \(number)")
}else{
    print("No phone number provided")
}



